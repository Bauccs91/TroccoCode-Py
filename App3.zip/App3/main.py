from fastapi import FastAPI, Form, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
import psycopg2

app = FastAPI()  # ✅ Solo una vez


# ---------------------------
# Conexión a PostgreSQL
# ---------------------------
def get_connection():
    return psycopg2.connect(
        host="localhost",   # Ajusta según tu contenedor
        port=5432,
        user="postgres",
        password="mysecretpassword",
        dbname="postgres"
    )

# ---------------------------
# fct_sales - Registro de ventas
# ---------------------------
@app.get("/sales", response_class=HTMLResponse)
def sales_form():
    return """
    <h2>Registrar Venta</h2>
    <form action="/add_sale" method="post">
        Cliente: <input type="text" name="customer_name"><br>
        Tipo Doc: <input type="text" name="id_type"><br>
        Número Doc: <input type="text" name="customer_id"><br>
        Teléfono: <input type="text" name="customer_phone"><br>
        Ciudad: <input type="text" name="customer_cty"><br>
        País: <input type="text" name="customer_ctry"><br>
        Dirección: <input type="text" name="customer_address"><br>
        Producto: <input type="text" name="product_name"><br>
        Cantidad: <input type="number" name="quantity"><br>
        <input type="submit" value="Registrar">
    </form>
    """

@app.post("/add_sale")
def add_sale(
    customer_name: str = Form(...),
    id_type: str = Form(...),
    customer_id: str = Form(...),
    customer_phone: str = Form(None),
    customer_cty: str = Form(None),
    customer_ctry: str = Form(None),
    customer_address: str = Form(None),
    product_name: str = Form(...),
    quantity: int = Form(...)
):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO lt_retailer.fct_sales (
            customer_name, id_type, customer_id, customer_phone,
            customer_cty, customer_ctry, customer_address,
            product_name, quantity
        )
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)
    """, (
        customer_name, id_type, customer_id, customer_phone,
        customer_cty, customer_ctry, customer_address,
        product_name, quantity
    ))
    conn.commit()
    cur.close()
    conn.close()
    return {"status": "Venta registrada correctamente"}

# ---------------------------
# dm_product - Productos
# ---------------------------
@app.get("/products", response_class=HTMLResponse)
def product_form():
    return """
    <h2>Registrar Producto</h2>
    <form action="/add_product" method="post">
        Activo (Y/N): <input type="text" name="active"><br>
        Nombre Producto: <input type="text" name="product_name"><br>
        Input_1: <input type="text" name="input_1"><br>
        Input_2: <input type="text" name="input_2"><br>
        Input_3: <input type="text" name="input_3"><br>
        Input_4: <input type="text" name="input_4"><br>
        Input_5: <input type="text" name="input_5"><br>
        Input_6: <input type="text" name="input_6"><br>
        Input_7: <input type="text" name="input_7"><br>
        Input_8: <input type="text" name="input_8"><br>
        Input_9: <input type="text" name="input_9"><br>
        <input type="submit" value="Registrar">
    </form>
    """

@app.post("/add_product")
def add_product(active: str = Form(...), product_name: str = Form(...),
                input_1: str = Form(None), input_2: str = Form(None)):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO dm_product (active, product_name, input_1, input_2)
        VALUES (%s,%s,%s,%s)
    """, (active, product_name, input_1, input_2))
    conn.commit()
    cur.close()
    conn.close()
    return {"status": "Producto registrado correctamente"}

# ---------------------------
# inputs_tb - Insumos
# ---------------------------
@app.get("/inputs", response_class=HTMLResponse)
def inputs_form():
    return """
    <h2>Registrar Insumo</h2>
    <form action="/add_input" method="post">
        Nombre Insumo: <input type="text" name="input_name"><br>
        Precio: <input type="number" step="0.01" name="price"><br>
        <input type="submit" value="Registrar">
    </form>
    """

@app.post("/add_input")
def add_input(input_name: str = Form(...), price: float = Form(...)):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("INSERT INTO lt_retailer.inputs_tb (input_name, price) VALUES (%s, %s)", (input_name, price))
    conn.commit()
    cur.close()
    conn.close()
    return {"status": "Insumo registrado correctamente"}

# ---------------------------
# menu_price - Menús
# ---------------------------
# @app.get("/menus", response_class=HTMLResponse)
# def menu_form():
#     return """
#     <h2>Registrar Menú</h2>
#     <form action="/add_menu" method="post">
#         Nombre Producto: <input type="text" name="product_name"><br>
#         Precio: <input type="number" name="product_price"><br>
#         <input type="submit" value="Registrar">
#     </form>
#     """

# @app.post("/add_menu")
# def add_menu(product_name: str = Form(...), product_price: int = Form(...)):
#     conn = get_connection()
#     cur = conn.cursor()
#     cur.execute("INSERT INTO lt_retailer.menu_price (product_name, product_price) VALUES (%s, %s)", (product_name, product_price))
#     conn.commit()
#     cur.close()
#     conn.close()
#     return {"status": "Menú registrado correctamente"}

# ---------------------------
# customer_satisfaction - Reseñas
# ---------------------------
@app.get("/reviews", response_class=HTMLResponse)
def review_form():
    return """
    <h2>Registrar Reseña</h2>
    <form action="/add_review" method="post">
        Cliente: <input type="text" name="customer_name"><br>
        Calificación (1-5): <input type="number" name="calification"><br>
        Comentarios: <input type="text" name="comments_review"><br>
        <input type="submit" value="Registrar">
    </form>
    """

@app.post("/add_review")
def add_review(customer_name: str = Form(...), calification: int = Form(...), comments_review: str = Form(None)):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO customer_satisfaction (customer_name, calification, comments_review)
        VALUES (%s, %s, %s)
    """, (customer_name, calification, comments_review))
    conn.commit()
    cur.close()
    conn.close()
    return {"status": "Reseña registrada correctamente"}

# ---------------------------
# expenses_tb - Gastos
# ---------------------------
@app.get("/expenses", response_class=HTMLResponse)
def expense_form():
    return """
    <h2>Registrar Gasto</h2>
    <form action="/add_expense" method="post">
        Concepto: <input type="text" name="concept_expense"><br>
        Monto: <input type="number" step="0.01" name="amount"><br>
        <input type="submit" value="Registrar">
    </form>
    """

@app.post("/add_expense")
def add_expense(concept_expense: str = Form(...), amount: float = Form(...)):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("INSERT INTO lt_retailer.expenses_tb (concept_expense, amount) VALUES (%s, %s)", (concept_expense, amount))
    conn.commit()
    cur.close()
    conn.close()
    return {"status": "Gasto registrado correctamente"}



templates = Jinja2Templates(directory="templates")

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("base.html", {"request": request})

from fastapi.staticfiles import StaticFiles
app.mount("/static", StaticFiles(directory="static"), name="static")